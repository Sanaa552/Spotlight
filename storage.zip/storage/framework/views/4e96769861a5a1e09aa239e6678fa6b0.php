<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-argent leading-tight">
            <?php echo e(__('Modération — Déclarations en attente')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-5xl mx-auto sm:px-6 lg:px-8 space-y-4">

            <?php if(session('success')): ?>
                <div class="bg-sonar/10 border border-sonar/30 text-sonar-dark px-4 py-3 rounded-lg">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($declarations->isEmpty()): ?>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-8 text-center text-gray-500">
                    Aucune déclaration en attente. 
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $declarations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $declaration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 <?php echo e($declaration->type === 'perte' ? 'border-alerte' : 'border-sonar'); ?>">
                        <div class="flex justify-between items-start gap-4">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <?php if (isset($component)) { $__componentOriginald74e7365b0089cf285115611975f05a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald74e7365b0089cf285115611975f05a9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.type-badge','data' => ['type' => $declaration->type]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('type-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($declaration->type)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald74e7365b0089cf285115611975f05a9)): ?>
<?php $attributes = $__attributesOriginald74e7365b0089cf285115611975f05a9; ?>
<?php unset($__attributesOriginald74e7365b0089cf285115611975f05a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald74e7365b0089cf285115611975f05a9)): ?>
<?php $component = $__componentOriginald74e7365b0089cf285115611975f05a9; ?>
<?php unset($__componentOriginald74e7365b0089cf285115611975f05a9); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['statut' => $declaration->statut]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['statut' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($declaration->statut)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                                    <span class="text-xs text-gray-400">#<?php echo e($declaration->id); ?></span>
                                </div>

                                <h3 class="font-semibold text-gray-900"><?php echo e($declaration->categorie); ?></h3>
                                <p class="text-sm text-gray-600 mt-1"><?php echo e($declaration->description); ?></p>

                                <div class="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500">
                                    <span> <?php echo e($declaration->citoyen->name); ?></span>
                                    <?php if($declaration->localisation): ?>
                                        <span> <?php echo e($declaration->localisation->adresse); ?></span>
                                    <?php endif; ?>
                                    <span> <?php echo e($declaration->created_at->diffForHumans()); ?></span>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 pt-4 border-t flex flex-wrap gap-3">
                            <form method="POST" action="<?php echo e(route('moderation.valider', $declaration)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                        class="inline-flex items-center px-4 py-2 bg-sonar border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-sonar-dark transition">
                                     Valider
                                </button>
                            </form>

                            <button type="button"
                                    onclick="document.getElementById('rejet-modal-<?php echo e($declaration->id); ?>').classList.remove('hidden')"
                                    class="inline-flex items-center px-4 py-2 bg-alerte border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-alerte-dark transition">
                                 Rejeter
                            </button>

                            <a href="<?php echo e(route('moderation.declarations.show', $declaration)); ?>"
                               class="inline-flex items-center px-4 py-2 text-xs font-semibold text-gray-500 hover:text-gray-800 uppercase tracking-widest">
                                Voir le détail
                            </a>
                        </div>

                        
                        <div id="rejet-modal-<?php echo e($declaration->id); ?>" class="hidden mt-4 bg-alerte/5 border border-alerte/20 rounded-lg p-4">
                            <form method="POST" action="<?php echo e(route('moderation.rejeter', $declaration)); ?>">
                                <?php echo csrf_field(); ?>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Motif du rejet</label>
                                <textarea name="motif_rejet" rows="2" required
                                          class="block w-full border-gray-300 rounded-md shadow-sm focus:border-alerte focus:ring-alerte"
                                          placeholder="Expliquez pourquoi cette déclaration est rejetée..."></textarea>
                                <div class="mt-3 flex gap-2">
                                    <button type="submit"
                                            class="px-4 py-2 bg-alerte text-white text-xs font-semibold uppercase rounded-md hover:bg-alerte-dark">
                                        Confirmer le rejet
                                    </button>
                                    <button type="button"
                                            onclick="document.getElementById('rejet-modal-<?php echo e($declaration->id); ?>').classList.add('hidden')"
                                            class="px-4 py-2 text-xs font-semibold text-gray-500 uppercase">
                                        Annuler
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="mt-4">
                    <?php echo e($declarations->links()); ?>

                </div>
            <?php endif; ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH E:\OEIL DE DIEU\GodEyes\resources\views/moderation/index.blade.php ENDPATH**/ ?>