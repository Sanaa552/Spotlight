<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'class' => 'w-5 h-5']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'class' => 'w-5 h-5']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$paths = [
    'location' => 'M12 21c-4.5-4.5-7-8.1-7-11.5A7 7 0 0119 9.5C19 12.9 16.5 16.5 12 21z M12 11.5a2 2 0 100-4 2 2 0 000 4z',
    'paperclip' => 'M8 12.5l6.5-6.5a3 3 0 114.24 4.24L10 18.5a5 5 0 01-7.07-7.07L11.5 3',
    'check-circle' => 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
    'x-circle' => 'M15 9l-6 6m0-6l6 6m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
    'shield' => 'M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z',
    'shield-check' => 'M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z M9 12l2 2 4-4',
    'user' => 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z',
    'clock' => 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
    'phone' => 'M3 5a2 2 0 012-2h2.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11 11 0 005.516 5.517l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z',
    'siren' => 'M12 9v4m0 4h.01M10.29 3.86l-8.18 14.18A2 2 0 003.82 21h16.36a2 2 0 001.71-2.96L13.71 3.86a2 2 0 00-3.42 0z',
    'fire' => 'M12 2c2 3-1 4-1 6 0 1.5 1 2 2 2s2-1 2-2c2 1 3 3 3 5.5A6.5 6.5 0 0112 20a6.5 6.5 0 01-6-9c1 1 2 1.5 2.5 1 .8-.8-.5-2-.5-4C8 5 10 3 12 2z',
    'medical' => 'M12 4v16m-8-8h16',
    'search' => 'M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.35-4.35',
    'megaphone' => 'M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13.5a3 3 0 000-6M3 9v6h1.5a2.5 2.5 0 010 5H3v-5m9.5-10.24L18 13.5',
    'bell' => 'M15 17h5l-1.4-1.4A2 2 0 0118 14.2V11a6 6 0 10-12 0v3.2c0 .5-.2 1-.6 1.4L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9',
    'camera' => 'M3 9a2 2 0 012-2h1.5l1-2h9l1 2H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z M12 17a4 4 0 100-8 4 4 0 000 8z',
    'car' => 'M5 17h14M6 17a2 2 0 11-4 0 2 2 0 014 0zm14 0a2 2 0 11-4 0 2 2 0 014 0zM4 17V9l2-5h12l2 5v8',
];
$path = $paths[$name] ?? $paths['location'];
?>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" <?php echo e($attributes->merge(['class' => $class])); ?>>
    <path d="<?php echo e($path); ?>" />
</svg><?php /**PATH E:\OEIL DE DIEU\GodEyes\resources\views/components/icon.blade.php ENDPATH**/ ?>