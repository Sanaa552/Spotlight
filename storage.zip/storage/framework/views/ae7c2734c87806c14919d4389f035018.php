<a <?php echo e($attributes->merge(['class' => 'block w-full px-4 py-2 text-start text-sm leading-5 text-argent/80 hover:bg-white/5 hover:text-argent focus:outline-none focus:bg-white/5 transition duration-150 ease-in-out'])); ?>>
    <?php echo e($slot); ?>

</a><?php /**PATH E:\OEIL DE DIEU\GodEyes\resources\views/components/dropdown-link.blade.php ENDPATH**/ ?>