<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['size' => 'text-2xl']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['size' => 'text-2xl']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<span class="<?php echo e($size); ?> font-bold text-argent tracking-tight">
    Spotl<span class="relative inline-block" style="width:0.32em; height:1em;">
        <span class="absolute bg-argent rounded-sm" style="left:50%; bottom:0; width:4px; height:0.6em; transform:translateX(-50%);"></span>
        <span class="absolute rounded-full bg-alerte" style="left:50%; top:0; width:6px; height:6px; transform:translateX(-50%);"></span>
    </span>ght
</span><?php /**PATH E:\OEIL DE DIEU\GodEyes\resources\views/components/spotlight-wordmark.blade.php ENDPATH**/ ?>