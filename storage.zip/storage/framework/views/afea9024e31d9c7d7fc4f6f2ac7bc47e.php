<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['statut']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['statut']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $styles = match ($statut) {
        'en_attente' => 'bg-yellow-100 text-yellow-800',
        'validee' => 'bg-green-100 text-green-800',
        'rejetee' => 'bg-red-100 text-red-800',
        'cloturee' => 'bg-gray-200 text-gray-700',
        default => 'bg-gray-100 text-gray-600',
    };

    $labels = [
        'en_attente' => 'En attente',
        'validee' => 'Validée',
        'rejetee' => 'Rejetée',
        'cloturee' => 'Clôturée',
    ];
?>

<span <?php echo e($attributes->merge(['class' => "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold $styles"])); ?>>
    <?php echo e($labels[$statut] ?? $statut); ?>

</span><?php /**PATH E:\OEIL DE DIEU\GodEyes\resources\views/components/status-badge.blade.php ENDPATH**/ ?>