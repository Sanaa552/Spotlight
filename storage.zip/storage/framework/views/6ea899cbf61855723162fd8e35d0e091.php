<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
       
       <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon-16x16.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('apple-touch-icon.png')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans text-gray-900 antialiased">
    <div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-nuit">
        <div>
            <a href="/" class="flex items-center gap-2">
                <img src="<?php echo e(asset('images/spotlight-icon.png')); ?>" alt="Spotlight" class="h-16 w-16 object-contain">
                <?php if (isset($component)) { $__componentOriginalf81b65b499d6627b0ac0eb2aa1de95ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf81b65b499d6627b0ac0eb2aa1de95ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spotlight-wordmark','data' => ['size' => 'text-3xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spotlight-wordmark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'text-3xl']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf81b65b499d6627b0ac0eb2aa1de95ea)): ?>
<?php $attributes = $__attributesOriginalf81b65b499d6627b0ac0eb2aa1de95ea; ?>
<?php unset($__attributesOriginalf81b65b499d6627b0ac0eb2aa1de95ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf81b65b499d6627b0ac0eb2aa1de95ea)): ?>
<?php $component = $__componentOriginalf81b65b499d6627b0ac0eb2aa1de95ea; ?>
<?php unset($__componentOriginalf81b65b499d6627b0ac0eb2aa1de95ea); ?>
<?php endif; ?>
            </a>
        </div>

        <div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
            <?php echo e($slot); ?>

        </div>
    </div>
</body>
</html><?php /**PATH E:\OEIL DE DIEU\GodEyes\resources\views/layouts/guest.blade.php ENDPATH**/ ?>