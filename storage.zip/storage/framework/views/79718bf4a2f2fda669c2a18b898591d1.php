<header class="border-b border-white/10 bg-nuit fixed top-0 inset-x-0 z-40">
    <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <a href="/" class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal85202830d38cfe4f9b84497b1137875f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal85202830d38cfe4f9b84497b1137875f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spotlight-icon','data' => ['class' => 'h-9 w-9']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spotlight-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-9 w-9']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal85202830d38cfe4f9b84497b1137875f)): ?>
<?php $attributes = $__attributesOriginal85202830d38cfe4f9b84497b1137875f; ?>
<?php unset($__attributesOriginal85202830d38cfe4f9b84497b1137875f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal85202830d38cfe4f9b84497b1137875f)): ?>
<?php $component = $__componentOriginal85202830d38cfe4f9b84497b1137875f; ?>
<?php unset($__componentOriginal85202830d38cfe4f9b84497b1137875f); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalf81b65b499d6627b0ac0eb2aa1de95ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf81b65b499d6627b0ac0eb2aa1de95ea = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.spotlight-wordmark','data' => ['size' => 'text-xl']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('spotlight-wordmark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'text-xl']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf81b65b499d6627b0ac0eb2aa1de95ea)): ?>
<?php $attributes = $__attributesOriginalf81b65b499d6627b0ac0eb2aa1de95ea; ?>
<?php unset($__attributesOriginalf81b65b499d6627b0ac0eb2aa1de95ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf81b65b499d6627b0ac0eb2aa1de95ea)): ?>
<?php $component = $__componentOriginalf81b65b499d6627b0ac0eb2aa1de95ea; ?>
<?php unset($__componentOriginalf81b65b499d6627b0ac0eb2aa1de95ea); ?>
<?php endif; ?>
        </a>

        <nav class="hidden sm:flex items-center gap-6">
            <a href="/" class="text-sm <?php echo e(request()->is('/') ? 'text-argent font-semibold' : 'text-argent/60 hover:text-argent'); ?> transition">
                Accueil
            </a>
            <a href="<?php echo e(route('public.declarations.index')); ?>" class="text-sm <?php echo e(request()->routeIs('public.declarations.index') ? 'text-argent font-semibold' : 'text-argent/60 hover:text-argent'); ?> transition">
                Voir les avis
            </a>
            <a href="<?php echo e(route('public.about')); ?>" class="text-sm <?php echo e(request()->routeIs('public.about') ? 'text-argent font-semibold' : 'text-argent/60 hover:text-argent'); ?> transition">
                À propos
            </a>
            <a href="<?php echo e(route('declarations.create')); ?>" class="text-sm text-argent/60 hover:text-argent transition">
                Ajouter une déclaration
            </a>
        </nav>

        <div class="flex items-center gap-3">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>"
                   class="inline-flex items-center px-5 py-2 bg-alerte border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-alerte-dark transition">
                    Tableau de bord
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="text-sm font-medium text-argent/70 hover:text-argent transition">
                    Se connecter
                </a>
                <a href="<?php echo e(route('register')); ?>"
                   class="inline-flex items-center px-5 py-2 bg-alerte border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-alerte-dark transition">
                    Créer un compte
                </a>
            <?php endif; ?>
        </div>
    </div>
</header>

<div class="h-[73px]"></div><?php /**PATH E:\OEIL DE DIEU\GodEyes\resources\views/components/public-nav.blade.php ENDPATH**/ ?>